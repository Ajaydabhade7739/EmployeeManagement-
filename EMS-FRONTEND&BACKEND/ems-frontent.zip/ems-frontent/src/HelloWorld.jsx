import React from 'react'

const HelloWorld = () => {
  return (
    <div>
        <h1 className='text-center tm-10 flex align-items-left'>HelloWorld</h1>
        </div>
  )
}

export default HelloWorld